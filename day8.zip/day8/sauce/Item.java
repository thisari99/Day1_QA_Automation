package com.rootcodelabs.java.day8.sauce;

public record Item(String itemName, String itemDescription,double price) {

}
